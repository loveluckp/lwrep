// index.js
const defaultAvatarUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'

Page({
  data: {
    tempImagePath: '',
    resultImage: ''
  },

  chooseImage() {
    wx.chooseImage({
      count: 1,
      sizeType: ['original'],
      sourceType: ['album'],
      success: (res) => {
        this.setData({
          tempImagePath: res.tempFilePaths[0],
          resultImage: ''
        });
      }
    });
  },

  removeBg() {
    if (!this.data.tempImagePath) {
      wx.showToast({
        title: '请先选择图片',
        icon: 'none'
      });
      return;
    }

    wx.showLoading({
      title: '处理中...'
    });

    wx.getFileSystemManager().readFile({
      filePath: this.data.tempImagePath,
      encoding: 'base64',
      success: (res) => {
        wx.request({
          url: 'https://api.remove.bg/v1.0/removebg',
          method: 'POST',
          header: {
            'X-Api-Key': 'PPw74GYo6913EcbnYSUKE3zX',
            'Content-Type': 'application/json'
          },
          data: {
            image_file_b64: res.data,
            size: 'auto'
          },
          responseType: 'arraybuffer',
          success: (res) => {
            if (res.statusCode === 200) {
              const fs = wx.getFileSystemManager();
              const filePath = `${wx.env.USER_DATA_PATH}/temp_${Date.now()}.png`;
              
              fs.writeFile({
                filePath: filePath,
                data: res.data,
                encoding: 'binary',
                success: () => {
                  this.setData({
                    resultImage: filePath
                  });
                  wx.hideLoading();
                },
                fail: (error) => {
                  console.error('写入文件失败:', error);
                  wx.hideLoading();
                  wx.showToast({
                    title: '保存文件失败',
                    icon: 'none'
                  });
                }
              });
            } else {
              wx.hideLoading();
              wx.showToast({
                title: '处理失败: ' + res.statusCode,
                icon: 'none'
              });
            }
          },
          fail: (error) => {
            console.error('请求失败:', error);
            wx.hideLoading();
            wx.showToast({
              title: '处理失败',
              icon: 'none'
            });
          }
        });
      },
      fail: (error) => {
        console.error('读取文件失败:', error);
        wx.hideLoading();
        wx.showToast({
          title: '读取图片失败',
          icon: 'none'
        });
      }
    });
  },

  saveImage() {
    if (!this.data.resultImage) {
      wx.showToast({
        title: '请先去除背景',
        icon: 'none'
      });
      return;
    }

    wx.saveImageToPhotosAlbum({
      filePath: this.data.resultImage,
      success: () => {
        wx.showToast({
          title: '保存成功',
          icon: 'success'
        });
      },
      fail: (err) => {
        console.error('保存失败:', err);
        wx.showToast({
          title: '保存失败',
          icon: 'none'
        });
      }
    });
  }
});
